﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBHomework7
{
    class Vendor
    {
        public int V_Code { get; set; }
        public string V_Name { get; set; }
        public string V_Contact { get; set; }
        public string V_Areacode { get; set; }
        public string V_Phone { get; set; }
        public string V_State { get; set; }
        public string V_Order { get; set; }

        public List<Product> Products;
    }
}
