﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Ryder Dale Walton
/// This program demonstrates different database joins.
/// It has a method that selects a single product, all products,
/// a vendor and all of said vendor's products, and all vendors
/// with all of their products.
/// </summary>
namespace DBHomework7
{
    class Program
    {
        public static string connectionString = @"Data Source=.\SQLEXPRESS;" + 
                                                 "Initial Catalog=Sales;" +
                                                 "Integrated Security=True;" + 
                                                 "Connect Timeout=15;" + 
                                                 "Encrypt=False;" + 
                                                 "TrustServerCertificate=True;" + 
                                                 "ApplicationIntent=ReadWrite;" + 
                                                 "MultiSubnetFailover=False";

        static void Main(string[] args)
        {
            //This section of main prints off a particular Product with
            //A particular vendor. It uses P_ID because P_CODE doesn't 
            //seem to work when following the example pattern.
            Console.WriteLine("Return one Product joined with Vendor");
            int productId = 8; //I understood that we need to use the P_ID b/c P_CODE blows up
            Product singleProduct = getSingleProduct(productId);
            if (singleProduct != null)
            {
                Console.WriteLine($"Product ID: {productId}");
                Console.WriteLine($"{singleProduct.P_Code}: {singleProduct.P_Descript}" +
                                  $"{singleProduct.P_Discount} {singleProduct.P_Indate}" +
                                  $"{singleProduct.P_Min} {singleProduct.P_Price}" +
                                  $"{singleProduct.P_Qoh} {singleProduct.Vendor.V_Name}" +
                                  $"{singleProduct.Vendor.V_Contact} {singleProduct.Vendor.V_State}");
            }
            else
            {
                Console.WriteLine($"\nProduct not found.");
            }

            //This section prints out every product that has a vendor, so
            //it must loop through for each item in the list
            Console.WriteLine("\n\nAll Products with a Vendor");
            List<Product> products = getAllProductsWithVendor();
            foreach (Product p in products)
            {
                Console.WriteLine($"{p.P_Code}: {p.P_Descript}" +
                                 $"{p.P_Discount} {p.P_Indate}" +
                                 $"{p.P_Min} {p.P_Price}" +
                                 $"{p.P_Qoh} {p.Vendor.V_Name}" +
                                 $"{p.Vendor.V_Contact} {p.Vendor.V_State}");
            }

            //This section prints out a particular vendor's products,
            //so it must loop through its product list
            Console.WriteLine("\n\nA Vendor with said vendor's products");
            int v_code = 23119;
            Vendor vendor = getAVendor(v_code);
            if(vendor != null)
            {
                Console.WriteLine($"Vendor V_Code: {vendor.V_Code}");
                Console.WriteLine($"Vender info: {vendor.V_Name} {vendor.V_Contact} {vendor.V_State} {vendor.V_Areacode} {vendor.V_Phone} {vendor.V_Order}");
                foreach(Product p in vendor.Products)
                {
                    Console.WriteLine($"\t{p.P_Descript}");
                }
            }
            else
            {
                Console.WriteLine($"{v_code} not found.");
            }

            //This section shows all vendors and all of their products
            //This requires nested loops.
            Console.WriteLine("\n\nAll Vendors and their products");
            List<Vendor> vendors = getAllVendors();
            foreach(Vendor v in vendors)
            {
                Console.WriteLine($"Vender info: {v.V_Name} {v.V_Contact} {v.V_State} {v.V_Areacode} {v.V_Phone} {v.V_Order}");
                foreach(Product p in v.Products)
                {
                    Console.WriteLine($"\t\t{p.P_Descript}");
                }
            }
        }

        /// <summary>
        /// This method works, though I am not entirely sure what is happening
        /// with the parameterized sql here. I think the _code might be
        /// expecting an integer to be passed in that represents the primary
        /// key. Whenever I pass it in like this, searching for a P_ID
        /// that matches the @P_CODE parameter, everything works as expected.
        /// If I try to use @P_ID or anthing like that, it blows up.
        /// So, I think there is something going on under the hood with
        /// Dapper that allows this to work instead of using the P_CODE string.
        /// </summary>
        /// <param name="productId">P_ID number in the DB</param>
        /// <returns></returns>
        public static Product getSingleProduct(int productId)
        {
            using (IDbConnection conn = new SqlConnection(connectionString))
            {
                string sql = @"select product.*, vendor.v_name, vendor.v_contact, vendor.v_state                               
                                from product, vendor
                                where product.v_code = vendor.v_code and P_ID = @P_Code";
                Product result = conn.Query<Product, Vendor, Product>(sql,
                    (p, v) =>
                    {
                        p.Vendor = v;
                        return p;
                    },
                    new { P_Code = productId },
                    splitOn: "V_Code"
                ).FirstOrDefault(); //grabs the first item returned or null

                return result;
            }
        }

        /// <summary>
        /// This method returns a list of products associated with
        /// a vendor. The Product model contains an instance of its
        /// Vendor model. The sql query will not grab products that
        /// do not have a vendor.
        /// </summary>
        /// <returns> A list of products </returns>
        public static List<Product> getAllProductsWithVendor()
        {
            using (IDbConnection conn = new SqlConnection(connectionString))
            {
                string sql = @"select product.*, vendor.v_name, vendor.v_contact, vendor.v_state
                                from product, vendor
                                where product.v_code = vendor.v_code";
                List<Product> result = conn.Query<Product, Vendor, Product>(sql,
                    (p, v) => //lambda function assigns the Product's vendor so that it is non-null
                    {
                        p.Vendor = v;
                        return p;
                    },
                    splitOn: "V_Code"
                ).AsList();

                return result;
            }
        }

        /// <summary>
        /// The v_code integer is passed in as a key to fetch the
        /// desired vendor. The vendor and all of said vendors 
        /// products are displayed. If the vendor has no products
        /// the sql query will not fetch them.
        /// </summary>
        /// <param name="v_code">V_CODE int PK in DB</param>
        /// <returns> A Vendor model</returns>
        public static Vendor getAVendor(int v_code)
        {
            Vendor vendor = null;
            using (IDbConnection conn = new SqlConnection(connectionString))
            {
                string sql = @"Select Vendor.*, product.p_descript
                                from vendor inner join product on vendor.v_code = product.v_code
                                where vendor.v_code = @V_Code";

                var result = conn.Query<Vendor, Product, Product>(sql,
                                                                (v, p) =>
                                                                {
                                                                    if (vendor == null)
                                                                        vendor = v;
                                                                    return p;
                                                                },
                                                                new { V_Code = v_code },
                                                                splitOn: "V_Order"
                                                                ).AsList();
                if (vendor != null)
                    vendor.Products = result;
            }

            return vendor;
        }

        /// <summary>
        /// This method returns all vendors that have products.
        /// It uses a dictionary called lookup rather than a list.
        /// </summary>
        /// <returns>A list of Vendors</returns>
        public static List<Vendor> getAllVendors()
        {
            var lookup = new Dictionary<int, Vendor>();
            using (IDbConnection conn = new SqlConnection(connectionString))
            {
                string sql = @"select * from vendor, product where vendor.v_code = product.v_code";
                conn.Query<Vendor, Product, Vendor>(sql, (v, p) =>
                {
                    Vendor vendor;
                    if (!lookup.TryGetValue(v.V_Code, out vendor)) // if it isn't in the dictionary,
                    {
                        vendor = v;
                        lookup.Add(v.V_Code, vendor); // then add it in
                    }
                    if (vendor.Products == null) // if there are no products, make the list
                        vendor.Products = new List<Product>();
                    vendor.Products.Add(p); // add the product to the list
                    return vendor; // return the created vendor object
                },
                splitOn: "V_Order"
                );
            }
            return lookup.Values.ToList();
        }
    }
}
