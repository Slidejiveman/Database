﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBHomework7
{
    class Product
    {
        
        public string P_Code { get; set; }
        public string P_Descript { get; set; }
        public DateTime P_Indate { get; set; }
        public int P_Qoh { get; set; }
        public int P_Min { get; set; }
        public float P_Price { get; set; }
        public float P_Discount { get; set; }
        public int V_Code { get; set; }

        public Vendor Vendor { get; set; }

    }
}
